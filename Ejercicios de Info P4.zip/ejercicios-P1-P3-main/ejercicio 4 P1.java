package operacion;
import java.itil.Scanner;
public class Operaciones {
  public static void main (String[] args) {
    double raiz = Math.sqrt(15); 
    
  System.out.println(raiz:);
  }
 }
